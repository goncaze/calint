import flet as ft
from mes_card import MesCard


class CalendarioView(ft.View):

    def __init__(self, page: ft.Page):
        super().__init__()
        self.page = page
        
        self.lv_meses = ft.ListView(
            # expand=True, 
            # expand=False, 
            spacing=10, 
            padding=20, 
            horizontal= True,
            # horizontal= False,
        )


        self.lv_meses.controls = [MesCard(self.page, 2024, i) for i in range(1,13) ]
        
        self.controls.append(
            ft.SafeArea(content = self.lv_meses, expand=True)
            # self.lv_meses
        )


    