import flet as ft
from mes_card import MesCard


class CalendarioView(ft.View):

    def __init__(self, page: ft.Page):
        super().__init__()
        self.page = page

        self.mes_card = MesCard(self.page)
        self.controls.append(self.mes_card)
