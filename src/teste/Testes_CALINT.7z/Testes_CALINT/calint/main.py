import flet as ft
import locale

from calendario_view import CalendarioView

locale.setlocale(locale.LC_ALL, "pt_BR.UTF-8")


class App:

    def __init__(self, page: ft.Page):
        self.page = page
        self.page.theme_mode = ft.ThemeMode.LIGHT
        self.page.window.width = 380
        self.page.window.height = 700

        # Conectar um manipulador de eventos ao page.on_route_change
        self.page.on_route_change = self.route_change
        self.page.on_view_pop = self.view_pop
        self.page.go("/")

    def route_change(self, route: ft.RouteChangeEvent):

        troute = ft.TemplateRoute(self.page.route)

        if troute.match("/"):

            self.page.views.clear()
            self.page.views.append(
                CalendarioView(self.page)
            )

        self.page.update()

    def view_pop(self, e):
        self.page.views.pop()
        top_view = self.page.views[-1]
        self.page.go(top_view.route)
        self.page.update()


def main(page: ft.Page):
    App(page)


if __name__ == "__main__":
    ft.app(target=main)
