import flet as ft
import calendar


class Cartao(ft.Card):

    def __init__(self):
        super().__init__()
        self.color = ft.colors.AMBER_100
        self.shadow_color = ft.colors.GREEN
        self.surface_tint_color = ft.colors.YELLOW_100
        self.elevation = 8.0
        self.show_border_on_foreground = True
        self.expand = True
        
        self.obj_calendar_d0 = calendar.Calendar(firstweekday=6)
        # obj_calendar_d1 = calendar.Calendar(firstweekday=1)
        calendar.setfirstweekday(calendar.SUNDAY)


        ###
        # As listas de containers representam as colunas dos dias da semana.
        # Cada unidade de container contém os dias da semana e o nome do dia.
        #
        self.lista_container_00 = [
            ft.Container(
                content=ft.Text(value="DOM"), 
                expand=True,
                alignment=ft.alignment.center,
                bgcolor=ft.colors.BLUE_100,
                border=ft.border.all(width=1, color=ft.colors.BLACK),
            )
        ]
        self.lista_container_01 = [
            ft.Container(
                content=ft.Text(value="SEG"), 
                expand=True,
                alignment=ft.alignment.center,
                bgcolor=ft.colors.BLUE_100,
                border=ft.border.all(width=1, color=ft.colors.BLACK),
            )
        ]
        self.lista_container_02 = [
            ft.Container(
                content=ft.Text(value="TER"), 
                expand=True,
                alignment=ft.alignment.center,
                bgcolor=ft.colors.BLUE_100,
                border=ft.border.all(width=1, color=ft.colors.BLACK),
            )
        ]
        self.lista_container_03 = [
            ft.Container(
                content=ft.Text(value="QUA"), 
                expand=True,
                alignment=ft.alignment.center,
                bgcolor=ft.colors.BLUE_100,
                border=ft.border.all(width=1, color=ft.colors.BLACK),
            )
        ]
        self.lista_container_04 = [
            ft.Container(
                content=ft.Text(value="QUI"), 
                expand=True,
                alignment=ft.alignment.center,
                bgcolor=ft.colors.BLUE_100,
                border=ft.border.all(width=1, color=ft.colors.BLACK),
            )
        ]
        self.lista_container_05 = [
            ft.Container(
                content=ft.Text(value="SEX"), 
                expand=True,
                alignment=ft.alignment.center,
                bgcolor=ft.colors.BLUE_100,
                border=ft.border.all(width=1, color=ft.colors.BLACK),
            )
        ]
        self.lista_container_06 = [
            ft.Container(
                content=ft.Text(value="SAB"), 
                expand=True,
                alignment=ft.alignment.center,
                bgcolor=ft.colors.BLUE_100,
                border=ft.border.all(width=1, color=ft.colors.BLACK),
            )
        ]

        ###
        # Essa lista dos containers serve para rodar um loop que irá gerar  
        # os containers contendo os dias do mês.
        #
        self.listas_containers: list[list] = [
            self.lista_container_00,
            self.lista_container_01,
            self.lista_container_02,
            self.lista_container_03,
            self.lista_container_04,
            self.lista_container_05,
            self.lista_container_06
        ]

        # self.i = 0
        # for dia in range(1, 32):
        # # for dia in self.obj_calendar_d0.itermonthdays(2024, 9):
        #     if self.i < 7:                
        #         # self.listas_containers[self.i].append(self.container(dia))
        #         print(f"{dia}", end="\t")
        #         self.i += 1                
        #     else:
        #         print(f"\n{dia}", end="\t")
        #         self.i = 0
        #         # self.listas_containers[0].append(self.container(dia))


        self.preencher_dias()


        ###
        # As colunas para cada dia da semana contendo os dias
        # do mês que estão nas listas de conteiners.
        #
        self.coluna_00 = ft.Column(self.lista_container_00, expand=True)
        self.coluna_01 = ft.Column(self.lista_container_01, expand=True)
        self.coluna_02 = ft.Column(self.lista_container_02, expand=True)
        self.coluna_03 = ft.Column(self.lista_container_03, expand=True)
        self.coluna_04 = ft.Column(self.lista_container_04, expand=True)
        self.coluna_05 = ft.Column(self.lista_container_05, expand=True)
        self.coluna_06 = ft.Column(self.lista_container_06, expand=True)


        ###
        # Uma Row para agrupar as colnas antes de incluir no Card.
        #
        self.linha: ft.Row = ft.Row(
            controls=[
                self.coluna_00,
                self.coluna_01,
                self.coluna_02,
                self.coluna_03,
                self.coluna_04,
                self.coluna_05,
                self.coluna_06
            ]
        )

        self.content = ft.Container(
            # padding=ft.padding.all(9.5),
            margin = 10,
            content = ft.Column(
                expand=True,
                controls=[
                    ft.Row(                        
                        controls=[
                            ft.Container(
                                content = ft.Text(value="OUTUBRO"),
                                alignment=ft.alignment.center,
                                expand=True,
                            ),
                        ],
                        expand=True    
                    ),
                    ft.Row( 
                        vertical_alignment=ft.CrossAxisAlignment.START,                                         
                        controls=[                    
                            self.coluna_00,
                            self.coluna_01,
                            self.coluna_02,
                            self.coluna_03,
                            self.coluna_04,
                            self.coluna_05,
                            self.coluna_06
                        ]
                    ),   
                ]   
            )      
        )
        

    def container(self, dia: int) -> ft.Container:
        if dia > 0:
             container = ft.Container(                
                content=ft.Text(value=dia),
                border=ft.border.all(width = 1, color=ft.colors.BLACK),
                expand=True,
                alignment=ft.alignment.center,
            )
        else:
            container = ft.Container(                
                content=ft.Text(value=""),
                expand=True,
                alignment=ft.alignment.center,
            )

        return container
    
    
    def preencher_dias(self):
        self.i = 0
        # for dia in range(1, 32):
        for dia in self.obj_calendar_d0.itermonthdays(2024, 10):
            # if dia > 0:
            if self.i < 7:                
                self.listas_containers[self.i].append(self.container(dia))
                print(f"{dia}", end="\t")
                self.i += 1                
            else:
                print(f"\n{dia}", end="\t")
                self.i = 1
                self.listas_containers[0].append(self.container(dia))
            # else:
            #     self.listas_containers[self.i].append(self.container(""))
            #     self.i += 1   