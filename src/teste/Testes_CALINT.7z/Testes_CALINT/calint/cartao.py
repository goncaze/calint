import flet as ft



class Cartao(ft.Card):

    def __init__(self):    
        super().__init__()
        self.color = ft.colors.AMBER_100
        self.shadow_color = ft.colors.GREEN
        self.surface_tint_color = ft.colors.YELLOW_100
        self.elevation = 8.0
        self.show_border_on_foreground = True
        # self.expand = True
        # self.height = 200