import flet as ft


class Cartao(ft.Card):

    def __init__(self):
        super().__init__()
        self.color = ft.colors.AMBER_100
        self.shadow_color = ft.colors.GREEN
        self.surface_tint_color = ft.colors.YELLOW_100
        self.elevation = 8.0
        self.show_border_on_foreground = True

        # self.coluna_00 = ft.Column(controls=[ft.Text(value="DOM")])
        # self.coluna_01 = ft.Column(controls=[ft.Text(value="SEG")])
        # self.coluna_02 = ft.Column(controls=[ft.Text(value="TER")])
        # self.coluna_03 = ft.Column(controls=[ft.Text(value="QUA")])
        # self.coluna_04 = ft.Column(controls=[ft.Text(value="QUI")])
        # self.coluna_05 = ft.Column(controls=[ft.Text(value="SEX")])
        # self.coluna_06 = ft.Column(controls=[ft.Text(value="SAB")])

        self.lista_00: list[ft.Container] = ft.Container(content=ft.Text(value="DOM"))
        self.lista_01: list[ft.Container] = ft.Container(content=ft.Text(value="SEG"))
        self.lista_02: list[ft.Container] = ft.Container(content=ft.Text(value="TER"))
        self.lista_03: list[ft.Container] = ft.Container(content=ft.Text(value="QUA"))
        self.lista_04: list[ft.Container] = ft.Container(content=ft.Text(value="QUI"))
        self.lista_05: list[ft.Container] = ft.Container(content=ft.Text(value="SEX"))
        self.lista_06: list[ft.Container] = ft.Container(content=ft.Text(value="SAB"))

        self.listas: list[list] = [
            self.lista_00,
            self.lista_01,
            self.lista_02,
            self.lista_03,
            self.lista_04,
            self.lista_05,
            self.lista_06,
        ]

        i = 0
        for dia in range(1, 32):
            # print(dia, end="\t")
            if i < 7:
                # self.linha.controls[i].controls.append(self.container(dia))
                self.listas[i].append(self.container(dia))
                i += 1
                print(f"{dia}", end="\t")
            else:
                print(f"{dia}")
                i = 0

        self.coluna_00 = ft.Column()
        self.coluna_01 = ft.Column()
        self.coluna_02 = ft.Column()
        self.coluna_03 = ft.Column()
        self.coluna_04 = ft.Column()
        self.coluna_05 = ft.Column()
        self.coluna_06 = ft.Column()

        self.linha = ft.Row(
            controls=[
                self.coluna_00,
                self.coluna_01,
                self.coluna_02,
                self.coluna_03,
                self.coluna_04,
                self.coluna_05,
                self.coluna_06,
            ]
        )

        for coluna, lista in zip(self.linha, self.listas):
            coluna.controls = [
                ft.Container(
                    content=lista,
                    expand=True,
                    bgcolor=ft.colors.CYAN_100,
                )
            ]

        # i = 0
        # for dia in range(1, 32):
        #     # print(dia, end="\t")
        #     if i < 7:
        #         # self.linha.controls[i].controls.append(ft.Text(value=dia))
        #         self.linha.controls[i].controls.append(self.container(dia))
        #         i += 1
        #         print(f"{dia}", end="\t")
        #     else:
        #         print(f"{dia}")
        #         i = 0

        self.content = self.linha  # self.contentor

    def container(self, dia: int) -> ft.Container:
        return ft.Container(
            content=ft.Text(value=dia),
            bgcolor=ft.colors.BLUE_100,
            expand=True,
        )
